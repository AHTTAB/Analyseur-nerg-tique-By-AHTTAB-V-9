
import React, { useState } from 'react';
import { Home } from './views/Home';
import { ExcelSelection } from './views/ExcelSelection';
import { ClouAnalysis } from './views/ClouAnalysis';
import { PrnAnalysis } from './views/PrnAnalysis';
import { ElsterAnalysis } from './views/ElsterAnalysis';
import { ActarisAnalysis } from './views/ActarisAnalysis';
import { BillingProfile } from './views/BillingProfile';
import { LoginPage } from './views/LoginPage';
import { ViewState } from './types';
import { FileText } from 'lucide-react';
import { OneeLogo } from './components/OneeLogo';

function App() {
  const [currentView, setCurrentView] = useState<ViewState>('LOGIN');

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {currentView !== 'LOGIN' && (
      <header className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-sm print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center h-auto md:h-32 py-4 md:py-0 gap-4 md:gap-0"> 
            <div 
              className="flex items-center gap-3 cursor-pointer hover:opacity-80 transition-opacity shrink-0 w-full md:w-auto justify-center md:justify-start" 
              onClick={() => setCurrentView('HOME')}
            >
              <div className="bg-blue-600 p-2 rounded-lg shrink-0">
                 <FileText className="w-8 h-8 text-white" />
              </div>
              <div className="flex flex-col items-center md:items-start">
                <span className="font-bold text-xl sm:text-2xl text-slate-900 tracking-tight leading-tight text-center md:text-left">
                  Analyseur Énergétique
                </span>
                <span className="text-sm text-slate-500 font-medium">By AHTTAB</span>
              </div>
            </div>
            <div className="flex items-center justify-center md:justify-end w-full md:flex-1 md:ml-4 h-24 md:h-full py-0 md:py-2">
                <div className="h-full w-full max-w-[650px] flex items-center justify-center md:justify-end">
                   <OneeLogo />
                </div>
            </div>
          </div>
        </div>
      </header>
      )}

      <main className="flex-grow">
        {currentView === 'LOGIN' && <LoginPage onLoginSuccess={() => setCurrentView('HOME')} />}
        {currentView === 'HOME' && <Home onNavigate={setCurrentView} />}
        {currentView === 'EXCEL_MENU' && <ExcelSelection onNavigate={setCurrentView} />}
        {currentView === 'CLOU_ANALYSIS' && <ClouAnalysis onNavigate={setCurrentView} />}
        {currentView === 'ELSTER_ANALYSIS' && <ElsterAnalysis onNavigate={setCurrentView} />}
        {currentView === 'ACTARIS_ANALYSIS' && <ActarisAnalysis onNavigate={setCurrentView} />}
        {currentView === 'PRN_ANALYSIS' && <PrnAnalysis onNavigate={setCurrentView} />}
        {currentView === 'BILLING_PROFILE' && <BillingProfile onNavigate={setCurrentView} />}
      </main>
      
      {currentView !== 'LOGIN' && (
      <footer className="bg-white border-t border-slate-200 py-6 mt-auto print:border-t-0">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Analyseur Énergétique By AHTTAB. Tous droits réservés.</p>
          <p className="mt-1 font-medium text-slate-600">ahttab1999@hotmail.fr | 0661933842</p>
        </div>
      </footer>
      )}
    </div>
  );
}

export default App;
