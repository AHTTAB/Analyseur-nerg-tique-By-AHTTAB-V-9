
import React, { useState, useEffect } from 'react';

export const OneeLogo = () => {
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const textAnchor = isMobile ? "middle" : "end";
  const xPosition = isMobile ? "450" : "890";
  const preserveAspectRatio = isMobile ? "xMidYMid meet" : "xMaxYMid meet";

  return (
    <svg 
      viewBox="0 0 900 180" 
      className="max-h-24 w-full"
      xmlns="http://www.w3.org/2000/svg"
      preserveAspectRatio={preserveAspectRatio}
    >
      <text x={xPosition} y="60" textAnchor={textAnchor} fontFamily="Arial, sans-serif" fontWeight="bold" fontSize="48" fill="#1d4ed8">
        المكتب الوطني للكهرباء والماء الصالح للشرب
      </text>
      <defs>
        <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#3b82f6" opacity="0" />
          <stop offset="20%" stopColor="#3b82f6" />
          <stop offset="50%" stopColor="#eab308" />
          <stop offset="100%" stopColor="#3b82f6" />
        </linearGradient>
      </defs>
      <line x1="50" y1="90" x2="850" y2="90" stroke="url(#lineGrad)" strokeWidth="5" />
      <text x={xPosition} y="145" textAnchor={textAnchor} fontFamily="Arial, sans-serif" fontSize="36" fontWeight="bold" fill="#1e3a8a">
        Office National de l'Electricité et de l'Eau Potable
      </text>
    </svg>
  );
};
