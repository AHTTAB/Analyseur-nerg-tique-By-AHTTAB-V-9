import * as XLSX from 'xlsx';
import { AnalysisResult, DataRow, PeriodResult, Season } from '../types';

// Helper to parse time string "HH:MM" or "HH:MM:SS" into minutes
const parseTimeToMinutes = (timeStr: string): number => {
  if (!timeStr || typeof timeStr !== 'string') return -1;
  const cleanTime = timeStr.trim();
  const parts = cleanTime.split(':');
  if (parts.length < 2) return -1;
  
  const hours = parseInt(parts[0], 10);
  const minutes = parseInt(parts[1], 10);
  
  if (isNaN(hours) || isNaN(minutes)) return -1;
  return hours * 60 + minutes;
};

// Combine date and time into a Date object
const combineToDate = (d: string, t: string): Date => {
  const [day, month, year] = d.split('/').map(Number);
  const [hour, minute] = t.split(':').map(Number);
  return new Date(year, month - 1, day, hour, minute);
};

// Filter top points based on min hours between them
const filterTopPointsWithTimeConstraint = (rows: DataRow[], minHours: number, onlySameDay: boolean): DataRow[] => {
  const sorted = [...rows].sort((a, b) => b.value - a.value);
  const result: DataRow[] = [];
  
  for (const row of sorted) {
    if (result.length >= 5) break; 
    
    const rowDate = combineToDate(row.date, row.time);
    const isTooClose = result.some(existing => {
      const existingDate = combineToDate(existing.date, existing.time);
      
      // If onlySameDay is true, ensure we only compare if on same day
      if (onlySameDay && row.date !== existing.date) {
        return false;
      }

      const diffHours = Math.abs(rowDate.getTime() - existingDate.getTime()) / (1000 * 60 * 60);
      return diffHours < minHours;
    });
    
    if (!isTooClose) {
      result.push(row);
    }
  }
  
  // Return the top peaks sorted by value descending
  return result.sort((a, b) => b.value - a.value);
};

// Helper to determine season
const getSeason = (date: Date): Season => {
  const month = date.getMonth(); 
  if (month >= 9 || month <= 2) {
    return Season.WINTER;
  }
  return Season.SUMMER;
};

// Shared Analysis Logic
const performSeasonAnalysis = (processedRows: DataRow[], minHoursBetweenPoints: number = 6, onlySameDay: boolean = false): AnalysisResult => {
    const topFiveGlobal = filterTopPointsWithTimeConstraint(processedRows, minHoursBetweenPoints, onlySameDay);
  
    let maxHP: DataRow | null = null;
    let maxPointe: DataRow | null = null;
    let maxCreux: DataRow | null = null;
  
    processedRows.forEach(row => {
      const [d, m, y] = row.date.split('/').map(Number);
      const dateObj = new Date(y, m - 1, d);
      const season = getSeason(dateObj);
      const t = parseTimeToMinutes(row.time);
      
      if (t === -1) return;
  
      let isHP = false;
      let isPointe = false;
      let isCreux = false;
  
      if (season === Season.WINTER) {
        if (t >= 430 && t <= 1020) isHP = true;
        else if (t >= 1030 && t <= 1320) isPointe = true;
        else if (t >= 1330 || t <= 420) isCreux = true;
      } else {
        if (t >= 430 && t <= 1080) isHP = true;
        else if (t >= 1090 && t <= 1380) isPointe = true;
        else if (t >= 1390 || t <= 420) isCreux = true;
      }
  
      if (isHP) { if (!maxHP || row.value > maxHP.value) maxHP = row; }
      if (isPointe) { if (!maxPointe || row.value > maxPointe.value) maxPointe = row; }
      if (isCreux) { if (!maxCreux || row.value > maxCreux.value) maxCreux = row; }
    });
  
    const formatPeriodResult = (row: DataRow | null, name: string): PeriodResult | null => {
      if (!row) return null;
      return { periodName: name, maxValue: row.value, date: row.date, time: row.time };
    };
  
    return {
      headers: [],
      topFiveGlobal,
      heuresPleines: formatPeriodResult(maxHP, "Heures Pleines"),
      heuresPointe: formatPeriodResult(maxPointe, "Heures de Pointe"),
      heuresCreuses: formatPeriodResult(maxCreux, "Heures Creuses"),
    };
};

const mergeDatasets = (datasets: DataRow[][]): DataRow[] => {
  if (datasets.length === 0) return [];
  if (datasets.length === 1) return datasets[0];

  const map = new Map<string, DataRow>();

  datasets.forEach(dataset => {
    dataset.forEach(row => {
      const key = `${row.date}|${row.time}`;
      if (map.has(key)) {
        const existing = map.get(key)!;
        existing.value += row.value;
        existing.reactiveValue = (existing.reactiveValue ?? 0) + (row.reactiveValue ?? 0);
        // Update fullRow[4] for active power (value) and fullRow[5] for reactive power
        existing.fullRow[4] = existing.value;
        existing.fullRow[5] = existing.reactiveValue;
      } else {
        map.set(key, { ...row, fullRow: [...row.fullRow] });
      }
    });
  });
  
  // Debug log
  console.log('mergeDatasets: Merged', map.size, 'unique timestamps from', datasets.length, 'files');

  return Array.from(map.values()).map((row, index) => ({
      ...row,
      originalIndex: index + 1,
  }));
};

const parseExcelDate = (rawDate: any): string => {
    if (typeof rawDate === 'number') {
        const ssfDate = XLSX.SSF.parse_date_code(rawDate);
        if (ssfDate) return `${ssfDate.d.toString().padStart(2, '0')}/${ssfDate.m.toString().padStart(2, '0')}/${ssfDate.y}`;
    } else if (typeof rawDate === 'string') {
        const parts = rawDate.trim().split(/[-/]/);
        if (parts.length === 3) return `${parts[0].padStart(2, '0')}/${parts[1].padStart(2, '0')}/${parts[2]}`;
    }
    return "";
};

const parseExcelTime = (rawTime: any): string => {
    if (typeof rawTime === 'number') {
         const totalSeconds = Math.round(rawTime * 24 * 60 * 60);
         const h = Math.floor(totalSeconds / 3600) % 24;
         const m = Math.floor((totalSeconds % 3600) / 60);
         return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
    } else if (typeof rawTime === 'string') {
        const parts = rawTime.trim().split(':');
        if (parts.length >= 2) return `${parts[0].padStart(2, '0')}:${parts[1].padStart(2, '0')}`;
    }
    return "";
};

const parseExcelNumber = (rawValue: any): number | null => {
    if (typeof rawValue === 'number') return rawValue;
    if (typeof rawValue === 'string') {
        const cleanStr = rawValue.replace(',', '.').replace(/[^\d.-]/g, '');
        if (cleanStr && !isNaN(parseFloat(cleanStr))) return parseFloat(cleanStr);
    }
    return null;
}

const extractClouRows = async (file: File): Promise<{ 
    rows: DataRow[], 
    billing: { 
        activeTotal: { ceJour: number, prec: number, diff: number }, 
        activePlein: { ceJour: number, prec: number, diff: number }, 
        activePointe: { ceJour: number, prec: number, diff: number }, 
        activeCreux: { ceJour: number, prec: number, diff: number },
        reactiveTotal: { ceJour: number, prec: number, diff: number }, 
        reactivePlein: { ceJour: number, prec: number, diff: number }, 
        reactivePointe: { ceJour: number, prec: number, diff: number }, 
        reactiveCreux: { ceJour: number, prec: number, diff: number },
        activeReTotal: { ceJour: number, prec: number, diff: number }, 
        activeRePlein: { ceJour: number, prec: number, diff: number }, 
        activeRePointe: { ceJour: number, prec: number, diff: number }, 
        activeReCreux: { ceJour: number, prec: number, diff: number },
        reactiveReTotal: { ceJour: number, prec: number, diff: number }, 
        reactiveRePlein: { ceJour: number, prec: number, diff: number }, 
        reactiveRePointe: { ceJour: number, prec: number, diff: number }, 
        reactiveReCreux: { ceJour: number, prec: number, diff: number }
    }
}> => {
  const data = await file.arrayBuffer();
  const workbook = XLSX.read(data, { cellDates: false });
  
  // Default billing structure
  const emptyCalc = { ceJour: 0, prec: 0, diff: 0 };
  const billing = {                
      activeTotal: emptyCalc, activePlein: emptyCalc, activePointe: emptyCalc, activeCreux: emptyCalc,
      reactiveTotal: emptyCalc, reactivePlein: emptyCalc, reactivePointe: emptyCalc, reactiveCreux: emptyCalc,
      activeReTotal: emptyCalc, activeRePlein: emptyCalc, activeRePointe: emptyCalc, activeReCreux: emptyCalc,
      reactiveReTotal: emptyCalc, reactiveRePlein: emptyCalc, reactiveRePointe: emptyCalc, reactiveReCreux: emptyCalc,
  };

  // Billing calculation
  const billingSheet = workbook.Sheets["Profil de facturation mensuel"];
  if (billingSheet) {
      const jsonData: any[][] = XLSX.utils.sheet_to_json(billingSheet, { header: 1 });
      if (jsonData.length >= 3) {
          const getVal = (r: number, c: number) => parseExcelNumber(jsonData[r][c]) ?? 0;
          const calc = (col: number) => {
              const ceJour = getVal(2, col);
              const prec = getVal(1, col);
              return { ceJour, prec, diff: ceJour - prec };
          };
          
          billing.activeTotal = calc(2);
          billing.activePlein = calc(3);
          billing.activePointe = calc(4);
          billing.activeCreux = calc(5);

          billing.reactiveTotal = calc(16);
          billing.reactivePlein = calc(17);
          billing.reactivePointe = calc(18);
          billing.reactiveCreux = calc(19);

          billing.activeReTotal = calc(9);
          billing.activeRePlein = calc(10);
          billing.activeRePointe = calc(11);
          billing.activeReCreux = calc(12);

          billing.reactiveReTotal = calc(23);
          billing.reactiveRePlein = calc(24);
          billing.reactiveRePointe = calc(25);
          billing.reactiveReCreux = calc(26);
      }
  }
  
  // Charge Profile Calculation
  const chargeSheet = workbook.Sheets["Profil de charge moyen"];
  const processedRows: DataRow[] = [];
  
  if (chargeSheet) {
      const jsonChargeData: any[][] = XLSX.utils.sheet_to_json(chargeSheet, { header: 1 });
      const IDX_DATE = 0; const IDX_TIME = 1; const IDX_VALUE = 3; const IDX_REACTIVE_VALUE = 4;
      
      for (let i = 0; i < jsonChargeData.length; i++) {
        const row = jsonChargeData[i];
        if (!row || row.length <= IDX_VALUE) continue;
        const value = parseExcelNumber(row[IDX_VALUE]);
        const reactiveValue = parseExcelNumber(row[IDX_REACTIVE_VALUE]);
        if (value === null) continue;
        const dateStr = parseExcelDate(row[IDX_DATE]);
        const timeStr = parseExcelTime(row[IDX_TIME]);
        if (!dateStr || !timeStr) continue;
        const displayRow = [...row]; displayRow[IDX_VALUE] = value;
        processedRows.push({ date: dateStr, time: timeStr, value: value, reactiveValue: reactiveValue ?? 0, originalIndex: i + 1, fullRow: displayRow });
      }
  }

  return { rows: processedRows, billing };
};

export const processClouFiles = async (files: File[], minHoursBetweenPoints: number = 6): Promise<AnalysisResult> => {
  if (files.length === 0) throw new Error("Aucun fichier sélectionné.");
  const allResults = await Promise.all(files.map(extractClouRows));
  const mergedRows = mergeDatasets(allResults.map(r => r.rows));
  
  if (mergedRows.length === 0) throw new Error("Aucune donnée valide trouvée.");
  
  // Calculate Totals
  const totalActiveEnergy = mergedRows.reduce((sum, row) => sum + row.value, 0);
  const totalReactiveEnergy = mergedRows.reduce((sum, row) => sum + (row.reactiveValue ?? 0), 0);
  const cosPhi = totalActiveEnergy / Math.sqrt(Math.pow(totalActiveEnergy, 2) + Math.pow(totalReactiveEnergy, 2));

  // Billing Totals (Aggregate by summing total, plein, pointe, creux separately? 
  // Wait, if it's multiple files, do we just *sum* the differences? 
  // The user says "puissance active* total" and "active* réactive total". 
  // For billing, if multiple files, should we sum index ce jour and index prec? 
  // Let's assume we maintain the logic from previous implementation for now (summing billed active which was billedActive).)
  
  const sumBilling = (key: 'activeTotal' | 'activePlein' | 'activePointe' | 'activeCreux' | 'reactiveTotal' | 'reactivePlein' | 'reactivePointe' | 'reactiveCreux' | 'activeReTotal' | 'activeRePlein' | 'activeRePointe' | 'activeReCreux' | 'reactiveReTotal' | 'reactiveRePlein' | 'reactiveRePointe' | 'reactiveReCreux') => {
      const ceJour = allResults.reduce((sum, r) => sum + r.billing[key].ceJour, 0);
      const prec = allResults.reduce((sum, r) => sum + r.billing[key].prec, 0);
      return { ceJour, prec, diff: ceJour - prec };
  }
  
  const billingActiveTotal = sumBilling('activeTotal');
  const billingActivePlein = sumBilling('activePlein');
  const billingActivePointe = sumBilling('activePointe');
  const billingActiveCreux = sumBilling('activeCreux');

  const billingReactiveTotal = sumBilling('reactiveTotal');
  const billingReactivePlein = sumBilling('reactivePlein');
  const billingReactivePointe = sumBilling('reactivePointe');
  const billingReactiveCreux = sumBilling('reactiveCreux');

  const billingActiveReTotal = sumBilling('activeReTotal');
  const billingActiveRePlein = sumBilling('activeRePlein');
  const billingActiveRePointe = sumBilling('activeRePointe');
  const billingActiveReCreux = sumBilling('activeReCreux');

  const billingReactiveReTotal = sumBilling('reactiveReTotal');
  const billingReactiveRePlein = sumBilling('reactiveRePlein');
  const billingReactiveRePointe = sumBilling('reactiveRePointe');
  const billingReactiveReCreux = sumBilling('reactiveReCreux');
  
  if (files.length > 1) {
    mergedRows.forEach(row => { row.fullRow = [row.date, row.time, "Somme", row.value, row.reactiveValue]; });
  }
  
  const result = performSeasonAnalysis(mergedRows, minHoursBetweenPoints, false);
  result.totalActiveEnergy = totalActiveEnergy;
  result.totalReactiveEnergy = totalReactiveEnergy;
  result.cosPhi = cosPhi;
  result.billingActiveTotal = billingActiveTotal;
  result.billingActivePlein = billingActivePlein;
  result.billingActivePointe = billingActivePointe;
  result.billingActiveCreux = billingActiveCreux;
  result.billingReactiveTotal = billingReactiveTotal;
  result.billingReactivePlein = billingReactivePlein;
  result.billingReactivePointe = billingReactivePointe;
  result.billingReactiveCreux = billingReactiveCreux;
  result.billingActiveReTotal = billingActiveReTotal;
  result.billingActiveRePlein = billingActiveRePlein;
  result.billingActiveRePointe = billingActiveRePointe;
  result.billingActiveReCreux = billingActiveReCreux;
  result.billingReactiveReTotal = billingReactiveReTotal;
  result.billingReactiveRePlein = billingReactiveRePlein;
  result.billingReactiveRePointe = billingReactiveRePointe;
  result.billingReactiveReCreux = billingReactiveReCreux;
  result.headers = ["Date", "Heure", "Info", "Total P. Active (kW)", "Total P. Réactive (kVar)"];
  return result;
};

const extractElsterRows = async (file: File): Promise<DataRow[]> => {
  const data = await file.arrayBuffer();
  const workbook = XLSX.read(data, { cellDates: false });
  const sheet = workbook.Sheets[workbook.SheetNames[workbook.SheetNames.length > 1 ? 1 : 0]];
  const jsonData: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1 });
  if (jsonData.length === 0) throw new Error(`Fichier ${file.name} vide.`);
  const IDX_DATE = 1; const IDX_TIME = 2; const IDX_VALUE = 4;
  const processedRows: DataRow[] = [];
  for (let i = 0; i < jsonData.length; i++) {
    const row = jsonData[i];
    if (!row || row.length <= IDX_VALUE) continue;
    const value = parseExcelNumber(row[IDX_VALUE]);
    if (value === null) continue;
    const dateStr = parseExcelDate(row[IDX_DATE]);
    const timeStr = parseExcelTime(row[IDX_TIME]);
    if (!dateStr || !timeStr) continue;
    const displayRow = [...row]; displayRow[IDX_VALUE] = value;
    processedRows.push({ date: dateStr, time: timeStr, value: value, originalIndex: i + 1, fullRow: displayRow });
  }
  return processedRows;
};

export const processElsterFiles = async (files: File[], minHoursBetweenPoints: number = 6, onlySameDay: boolean = false): Promise<AnalysisResult> => {
    if (files.length === 0) throw new Error("Aucun fichier sélectionné.");
    const allDatasets = await Promise.all(files.map(extractElsterRows));
    const mergedRows = mergeDatasets(allDatasets);
    if (mergedRows.length === 0) throw new Error("Aucune donnée valide trouvée.");
    if (files.length > 1) {
        mergedRows.forEach(row => { row.fullRow = ["Global", row.date, row.time, "-", row.value, "-"]; });
    }
    const result = performSeasonAnalysis(mergedRows, minHoursBetweenPoints, onlySameDay);
    result.headers = ["Nom", "Date", "Heure", "Info 1", "Total P. Active (kW)", "Info 2"];
    return result;
};

const extractActarisRows = async (file: File): Promise<DataRow[]> => {
    const data = await file.arrayBuffer();
    const workbook = XLSX.read(data, { cellDates: false });
    const sheet = workbook.Sheets[workbook.Sheets["Données des Courbes de Charge"] ? "Données des Courbes de Charge" : workbook.SheetNames[0]];
    const jsonData: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    if (jsonData.length === 0) throw new Error(`Fichier ${file.name} vide.`);
    const IDX_DATE = 0; const IDX_TIME = 1; const IDX_VALUE = 2;
    const processedRows: DataRow[] = [];
    let lastValidDate = "";
    for (let i = 0; i < jsonData.length; i++) {
      const row = jsonData[i];
      if (!row || row.length <= IDX_VALUE) continue;
      let dateStr = row[IDX_DATE] ? parseExcelDate(row[IDX_DATE]) : lastValidDate;
      if (dateStr) lastValidDate = dateStr;
      const timeStr = parseExcelTime(row[IDX_TIME]);
      const value = parseExcelNumber(row[IDX_VALUE]);
      if (dateStr && timeStr && value !== null) {
        processedRows.push({ date: dateStr, time: timeStr, value: value, originalIndex: i + 1, fullRow: [dateStr, timeStr, value] });
      }
    }
    return processedRows;
};

export const processActarisFiles = async (files: File[], minHoursBetweenPoints: number = 6): Promise<AnalysisResult> => {
    if (files.length === 0) throw new Error("Aucun fichier sélectionné.");
    const allDatasets = await Promise.all(files.map(extractActarisRows));
    const mergedRows = mergeDatasets(allDatasets);
    if (mergedRows.length === 0) throw new Error("Aucune donnée valide trouvée.");
    
    // Calculate Totals
    const totalActiveEnergy = mergedRows.reduce((sum, row) => sum + row.value, 0);
    const totalReactiveEnergy = mergedRows.reduce((sum, row) => sum + (row.reactiveValue ?? 0), 0);
    const cosPhi = totalActiveEnergy / Math.sqrt(Math.pow(totalActiveEnergy, 2) + Math.pow(totalReactiveEnergy, 2));

    if (files.length > 1) {
      mergedRows.forEach(row => { row.fullRow = [row.date, row.time, row.value, row.reactiveValue]; });
    }
    const result = performSeasonAnalysis(mergedRows, minHoursBetweenPoints, false);
    result.totalActiveEnergy = totalActiveEnergy;
    result.totalReactiveEnergy = totalReactiveEnergy;
    result.cosPhi = cosPhi;
    result.headers = ["Date", "Heure", "P. Active (kW)", "P. Réactive (kVar)"];
    return result;
};

const extractPrnRows = async (file: File): Promise<DataRow[]> => {
  const text = await file.text();
  const lines = text.split(/\r?\n/);
  const processedRows: DataRow[] = [];
  for (let i = 0; i < lines.length; i++) {
    const match = lines[i].trim().match(/^"([^"]+)"\s+"([^"]+)"\s+"([^"]+)"\s+(\S+)\s+(\S+)\s+(\S+).*$/);
    if (!match) continue;
    const value = parseExcelNumber(match[5]);
    const reactiveValue = parseExcelNumber(match[6]);
    if (value === null) continue;
    
    // Normalize date/time format (assuming DD/MM/YYYY and HH:MM)
    const dateStr = match[2].trim();
    const timeStr = match[3].trim();
    
    processedRows.push({ 
        date: dateStr, 
        time: timeStr, 
        value: value, 
        reactiveValue: reactiveValue ?? 0,
        originalIndex: i + 1, 
        fullRow: [match[1], dateStr, timeStr, match[4], value, reactiveValue] 
    });
  }
  return processedRows;
};

export const processPrnFiles = async (files: File[], minHoursBetweenPoints: number = 6): Promise<AnalysisResult> => {
  if (files.length === 0) throw new Error("Aucun fichier sélectionné.");
  
  const allDatasets: DataRow[][] = [];
  const errors: string[] = [];
  
  for (const file of files) {
    try {
      allDatasets.push(await extractPrnRows(file));
    } catch (e) {
      errors.push(`Erreur lors de la lecture du fichier ${file.name}: ${e instanceof Error ? e.message : String(e)}`);
    }
  }

  if (allDatasets.length === 0) {
    throw new Error(`Aucun fichier n'a pu être lu :\n${errors.join('\n')}`);
  }

  const mergedRows = mergeDatasets(allDatasets);
  if (mergedRows.length === 0) throw new Error("Aucune donnée valide trouvée.");
  
  // Calculate Totals
  const totalActiveEnergy = mergedRows.reduce((sum, row) => sum + row.value, 0);
  const totalReactiveEnergy = mergedRows.reduce((sum, row) => sum + (row.reactiveValue ?? 0), 0);
  const cosPhi = totalActiveEnergy / Math.sqrt(Math.pow(totalActiveEnergy, 2) + Math.pow(totalReactiveEnergy, 2));

  // Perform Analysis using mergedRows where active power is already summed
  const result = performSeasonAnalysis(mergedRows, minHoursBetweenPoints, false);
  result.totalActiveEnergy = totalActiveEnergy;
  result.totalReactiveEnergy = totalReactiveEnergy;
  result.cosPhi = cosPhi;
  result.headers = ["Nom", "Date", "Heure", "ID", "Total P. Active (kW)", "P. Réactive (kVar)"];
  
  if (errors.length > 0) result.errors = errors;

  return result;
};
