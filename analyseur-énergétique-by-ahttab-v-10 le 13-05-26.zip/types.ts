export type ViewState = 'LOGIN' | 'HOME' | 'EXCEL_MENU' | 'CLOU_ANALYSIS' | 'ELSTER_ANALYSIS' | 'ACTARIS_ANALYSIS' | 'PRN_ANALYSIS' | 'BILLING_PROFILE';

export interface DataRow {
  date: string;
  time: string;
  value: number;
  reactiveValue?: number;
  originalIndex: number;
  fullRow: any[];
}

export interface PeriodResult {
  periodName: string; // e.g., "Heures Pleines"
  maxValue: number;
  date: string;
  time: string;
}

export interface AnalysisResult {
  headers: string[];
  topFiveGlobal: DataRow[];
  heuresPleines: PeriodResult | null;
  heuresPointe: PeriodResult | null;
  heuresCreuses: PeriodResult | null;
  totalActiveEnergy?: number;
  totalReactiveEnergy?: number;
  cosPhi?: number;
  billingActiveTotal?: { ceJour: number, prec: number, diff: number };
  billingActivePlein?: { ceJour: number, prec: number, diff: number };
  billingActivePointe?: { ceJour: number, prec: number, diff: number };
  billingActiveCreux?: { ceJour: number, prec: number, diff: number };
  billingReactiveTotal?: { ceJour: number, prec: number, diff: number };
  billingReactivePlein?: { ceJour: number, prec: number, diff: number };
  billingReactivePointe?: { ceJour: number, prec: number, diff: number };
  billingReactiveCreux?: { ceJour: number, prec: number, diff: number };
  billingActiveReTotal?: { ceJour: number, prec: number, diff: number };
  billingActiveRePlein?: { ceJour: number, prec: number, diff: number };
  billingActiveRePointe?: { ceJour: number, prec: number, diff: number };
  billingActiveReCreux?: { ceJour: number, prec: number, diff: number };
  billingReactiveReTotal?: { ceJour: number, prec: number, diff: number };
  billingReactiveRePlein?: { ceJour: number, prec: number, diff: number };
  billingReactiveRePointe?: { ceJour: number, prec: number, diff: number };
  billingReactiveReCreux?: { ceJour: number, prec: number, diff: number };
  errors?: string[];
}

// Alias for backward compatibility if needed, or just use AnalysisResult everywhere
export type ClouAnalysisResult = AnalysisResult;
export type ElsterAnalysisResult = AnalysisResult;

export enum Season {
  WINTER = 'WINTER', // Oct - Mar
  SUMMER = 'SUMMER', // Apr - Sep
}