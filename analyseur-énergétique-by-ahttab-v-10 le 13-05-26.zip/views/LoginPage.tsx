import React, { useState } from 'react';
import { OneeLogo } from '../components/OneeLogo';

interface LoginPageProps {
  onLoginSuccess: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'ahttab' && password === 'ahttab') {
      onLoginSuccess();
    } else {
      setError('Nom d\'utilisateur ou mot de passe incorrect.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0f172a] px-4 relative overflow-hidden">
      {/* Background Electricity Pattern */}
      <div className="absolute inset-0 opacity-10" 
           style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, #60a5fa 1px, transparent 0)', backgroundSize: '40px 40px' }}>
      </div>
      
      <div className="max-w-md w-full bg-white/95 backdrop-blur-md p-10 rounded-3xl shadow-[0_0_50px_-12px_rgba(37,99,235,0.3)] border border-blue-100 relative z-10">
        <div className="mb-10 flex flex-col items-center">
            <div className="p-2 bg-slate-50 rounded-2xl shadow-inner mb-6">
                <OneeLogo />
            </div>
            <h1 className="text-center text-3xl font-extrabold text-slate-800 tracking-tight">Analyseur Énergétique</h1>
            <p className="text-center text-blue-600 font-medium mt-2">Gestion et Analyse de Réseaux</p>
        </div>
        
        {error && <p className="text-red-500 text-center mb-6 bg-red-50 py-3 px-4 rounded-xl text-sm font-medium">{error}</p>}
        
        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-slate-600 mb-2 uppercase tracking-wider">Utilisateur</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full rounded-xl border-slate-200 border bg-slate-50/50 p-4 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition outline-none"
              placeholder="Entrez votre identifiant"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-600 mb-2 uppercase tracking-wider">Mot de passe</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border-slate-200 border bg-slate-50/50 p-4 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition outline-none"
              placeholder="••••••••"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-[#1e3a8a] text-white font-bold py-4 px-4 rounded-xl hover:bg-blue-900 transition-all duration-300 transform hover:scale-[1.01]"
          >
            Se connecter
          </button>
        </form>
      </div>
    </div>
  );
};
