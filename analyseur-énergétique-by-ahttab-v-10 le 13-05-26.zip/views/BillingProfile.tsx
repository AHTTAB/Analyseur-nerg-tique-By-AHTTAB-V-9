import React from 'react';
import { ViewState } from '../types';

export const BillingProfile = ({ onNavigate }: { onNavigate: (view: ViewState) => void }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold text-slate-800 mb-6">Profil de facturation mensuel</h1>
      <p className="text-slate-600">Cette page est en cours de développement.</p>
    </div>
  );
};
